import tkinter as tk
from tkinter import messagebox
import urllib.request
import json
import webbrowser
from datetime import datetime

window = tk.Tk()
window.title("Women Safety Assistant")
window.geometry("500x750")
window.resizable(False, False)

contacts = []
history = []
timer_running = False
time_left = 0


def get_location():
    try:
        url = "https://ipinfo.io/json"
        with urllib.request.urlopen(url, timeout=5) as response:
            data = json.loads(response.read().decode())

        location = data.get("loc")
        if location:
            latitude, longitude = location.split(",")
            return latitude, longitude
    except Exception:
        pass

    return None, None


def open_map():
    latitude, longitude = get_location()

    if latitude is None:
        messagebox.showerror(
            "Location Error",
            "Unable to get the current location."
        )
        return

    map_url = (
        "https://www.google.com/maps/search/?api=1"
        "&query=" + latitude + "," + longitude
    )
    webbrowser.open(map_url)


def add_contact():
    name = name_entry.get().strip()
    number = number_entry.get().strip()

    if name == "" or number == "":
        messagebox.showerror(
            "Error",
            "Please enter both name and phone number."
        )
        return

    contacts.append([name, number])
    contact_list.insert(tk.END, name + " - " + number)

    name_entry.delete(0, tk.END)
    number_entry.delete(0, tk.END)


def delete_contact():
    selected = contact_list.curselection()

    if not selected:
        messagebox.showerror("Error", "Please select a contact.")
        return

    index = selected[0]
    contact_list.delete(index)
    contacts.pop(index)


def sos():
    selected = contact_list.curselection()

    if not selected:
        messagebox.showerror(
            "No Contact Selected",
            "Please select an emergency contact first."
        )
        return

    name, number = contacts[selected[0]]
    latitude, longitude = get_location()

    if latitude is not None:
        map_url = (
            "https://www.google.com/maps/search/?api=1"
            "&query=" + latitude + "," + longitude
        )
        location_text = (
            "Latitude: " + latitude +
            "\nLongitude: " + longitude +
            "\nMap: " + map_url
        )
    else:
        location_text = "Location unavailable."

    message = (
        "EMERGENCY ALERT\n\n"
        "I may need help.\n"
        "Please check on me immediately.\n\n"
        "Emergency Contact: " + name +
        "\nContact Number: " + number +
        "\n\n" + location_text
    )

    current_time = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    history.append("SOS activated at " + current_time + " for " + name)
    history_list.insert(tk.END, "SOS - " + current_time)

    for _ in range(3):
        window.bell()

    messagebox.showwarning("SOS ACTIVATED", message)


def start_timer():
    global timer_running, time_left

    try:
        minutes = int(timer_entry.get())
        if minutes <= 0:
            raise ValueError
    except ValueError:
        messagebox.showerror(
            "Invalid Time",
            "Enter a positive number of minutes."
        )
        return

    time_left = minutes * 60
    timer_running = True
    update_timer()


def update_timer():
    global timer_running, time_left

    if not timer_running:
        return

    minutes = time_left // 60
    seconds = time_left % 60
    timer_label.config(text="Safety Timer: {:02d}:{:02d}".format(minutes, seconds))

    if time_left > 0:
        time_left -= 1
        window.after(1000, update_timer)
    else:
        timer_running = False
        for _ in range(5):
            window.bell()
        messagebox.showwarning(
            "Timer Finished",
            "Safety timer has ended.\n\nPlease confirm that you are safe."
        )


def stop_timer():
    global timer_running, time_left

    timer_running = False
    time_left = 0
    timer_label.config(text="Safety Timer: 00:00")


def i_am_safe():
    global timer_running, time_left

    timer_running = False
    time_left = 0
    timer_label.config(text="Safety Timer: 00:00")

    current_time = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    history.append("User confirmed safety at " + current_time)
    history_list.insert(tk.END, "I'm Safe - " + current_time)

    messagebox.showinfo(
        "Safety Confirmed",
        "You have been marked as safe."
    )


def clear_history():
    history.clear()
    history_list.delete(0, tk.END)


title = tk.Label(
    window,
    text="WOMEN SAFETY ASSISTANT",
    font=("Arial", 20, "bold")
)
title.pack(pady=15)

subtitle = tk.Label(
    window,
    text="Emergency Safety Prototype",
    font=("Arial", 11)
)
subtitle.pack()

sos_button = tk.Button(
    window,
    text="🆘 SOS",
    font=("Arial", 22, "bold"),
    command=sos,
    width=12,
    height=2
)
sos_button.pack(pady=15)

contact_title = tk.Label(
    window,
    text="Emergency Contacts",
    font=("Arial", 14, "bold")
)
contact_title.pack(pady=5)

name_entry = tk.Entry(window, width=35)
name_entry.pack(pady=3)

number_entry = tk.Entry(window, width=35)
number_entry.pack(pady=3)

add_button = tk.Button(window, text="Add Contact", command=add_contact)
add_button.pack(pady=5)

contact_list = tk.Listbox(window, width=42, height=4)
contact_list.pack(pady=5)

delete_button = tk.Button(
    window,
    text="Delete Selected Contact",
    command=delete_contact
)
delete_button.pack(pady=3)

location_button = tk.Button(
    window,
    text="📍 Open Current Location",
    command=open_map
)
location_button.pack(pady=8)

timer_title = tk.Label(
    window,
    text="Safety Check-in Timer",
    font=("Arial", 14, "bold")
)
timer_title.pack(pady=5)

timer_entry = tk.Entry(window, width=15)
timer_entry.pack(pady=3)

start_button = tk.Button(window, text="Start Timer", command=start_timer)
start_button.pack(pady=3)

stop_button = tk.Button(window, text="Stop Timer", command=stop_timer)
stop_button.pack(pady=3)

timer_label = tk.Label(
    window,
    text="Safety Timer: 00:00",
    font=("Arial", 12, "bold")
)
timer_label.pack(pady=5)

safe_button = tk.Button(
    window,
    text="✅ I'm Safe",
    command=i_am_safe
)
safe_button.pack(pady=5)

history_title = tk.Label(
    window,
    text="Emergency History",
    font=("Arial", 14, "bold")
)
history_title.pack(pady=5)

history_list = tk.Listbox(window, width=55, height=5)
history_list.pack(pady=5)

clear_button = tk.Button(
    window,
    text="Clear History",
    command=clear_history
)
clear_button.pack(pady=3)

window.mainloop()
