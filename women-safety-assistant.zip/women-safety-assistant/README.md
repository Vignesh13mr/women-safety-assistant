# 🛡️ Women Safety Assistant

A Python-based women safety emergency assistant prototype.

> **Important:** This is an educational prototype. It does not make real emergency calls or send real SMS messages.

## Features

- 🆘 SOS emergency alert
- 👥 Add and remove emergency contacts
- 📍 Retrieve approximate IP-based location
- 🗺️ Open the location in Google Maps
- 💬 Generate an emergency message
- ⏱️ Safety check-in timer
- ✅ "I'm Safe" confirmation
- 🔊 Alert sound
- 📜 Emergency event history

## Technologies

- Python
- Tkinter
- JSON
- `urllib`
- `webbrowser`
- `datetime`

The project currently uses only Python standard-library modules, so no third-party package is required.

## Project Structure

```text
women-safety-assistant/
├── women_safety.py
├── README.md
├── requirements.txt
└── screenshots/
```

## Run the Project

Make sure Python 3 is installed.

```bash
python women_safety.py
```

On some systems you may need:

```bash
python3 women_safety.py
```

## Testing

Use dummy/test contact information. Do not put real people's private phone numbers in a public GitHub repository.

Example:

```text
Mother - XXXXXXXX01
Friend - XXXXXXXX02
```

The SOS button generates a simulated emergency alert. It does not contact anyone.

## Location Limitation

The current prototype uses IP-based location information. This is approximate and is not the same as precise device GPS.

A future mobile version could use device GPS/location services.

## AI-Assisted Development

AI tools were used as a programming and learning assistant during development. The project concept and feature requirements were designed by the project creator, while AI assistance was used for implementation, debugging, and explanations.

## Future Improvements

- Modern mobile UI
- More accurate GPS
- Persistent contact storage
- PIN/security
- Better accessibility
- Mobile application support
- Additional safety resources

## Project Status

**Working educational prototype**
